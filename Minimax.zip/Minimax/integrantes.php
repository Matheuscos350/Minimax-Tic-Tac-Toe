<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOGO-DA-VELHA</title>
    
</head>
<body>
    <link rel="stylesheet" href="css/style.css">

<?php


include("cabecalho.php")

?>


<center><h1>Projeto elaborado para PROJETO EM SISTEMAS INTELIGENTES</h1></center>

<!-- <center><h3>Integrantes</h3></center>

<center><h4>Júlia Pedroso dos Santos (324101087) (Líder)</h4></center>
<center><h4>Gabriel Cruz dos Santos (324101551)</h4></center>
<center><h4>Gabriel Genaro Cardoso Ferreira (323102009) </h4></center>
<center><h4>Karine Arrivail De Oliveira (324100971)</h4></center>
<center><h4>Matheus Costa Machado (324101970) </h4></center>
<center><h4>Milton Omar Rojas Sacari (323201387)</h4></center>
<center><h4>Renan Antonio da Silva (324100796) </h4></center>
<center><h4>Ruan de Moura Rodrigues (324100862)</h4></center> -->
<center><h4><Img id="#" src="img/uni9.png"><h4></center>


<?php
include("rodape.php")
?>